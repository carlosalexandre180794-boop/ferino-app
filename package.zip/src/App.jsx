import "./App.css";
import { Routes, Route } from "react-router-dom";

import Header from "./components/Header";
import Menu from "./components/Menu";

import Home from "./pages/Home";
import Partidas from "./pages/Partidas";
import Classificacao from "./pages/Classificacao";
import Estatisticas from "./pages/Estatisticas";
import Jogadores from "./pages/Jogadores";

function App() {
  return (
    <div className="app">
      <Header />
      <Menu />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/partidas" element={<Partidas />} />
        <Route path="/classificacao" element={<Classificacao />} />
        <Route path="/estatisticas" element={<Estatisticas />} />
        <Route path="/jogadores" element={<Jogadores />} />
      </Routes>
    </div>
  );
}

export default App;