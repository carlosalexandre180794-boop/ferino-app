function GoleiroMes({ goleiro }) {
  if (!goleiro) {
    return (
      <article className="goalkeeper-card">
        <span className="panel-label">GOLEIRO DO MÊS</span>
        <h3>Nenhum goleiro</h3>
      </article>
    );
  }

  return (
    <article className="goalkeeper-card">
      <div>
        <span className="panel-label">GOLEIRO DO MÊS</span>

        <h3>{goleiro.nome}</h3>

        <p>{goleiro.time}</p>

        <small>{goleiro.jogos} jogo(s)</small>
      </div>

      <div className="clean-sheet">
        <strong>{goleiro.gols_sofridos}</strong>
        <span>gols sofridos</span>
      </div>
    </article>
  );
}

export default GoleiroMes;