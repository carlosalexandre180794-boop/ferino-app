function Header() {
  return (
    <header className="topbar">
      <div>
        <span className="eyebrow">CAMPEONATO MENSAL</span>
        <h1>Ferino Pé de Pano</h1>
        <p>Temporada 2026 • Julho</p>
      </div>

      <div className="status">
        <span className="status-dot" />
        Rodada em andamento
      </div>
    </header>
  );
}

export default Header;