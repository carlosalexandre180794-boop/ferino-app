import { NavLink } from "react-router-dom";

function Menu() {
  return (
    <nav className="menu">
      <NavLink
        to="/"
        end
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Visão geral
      </NavLink>

      <NavLink
        to="/partidas"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Partidas
      </NavLink>

      <NavLink
        to="/classificacao"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Classificação
      </NavLink>

      <NavLink
        to="/estatisticas"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Estatísticas
      </NavLink>

      <NavLink
        to="/jogadores"
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Jogadores
      </NavLink>
    </nav>
  );
}

export default Menu;