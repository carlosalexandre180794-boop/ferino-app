function Tabela({ classificacao }) {
  return (
    <article className="panel standings-panel">
      <div className="panel-header">
        <div>
          <span className="panel-label">TABELA</span>
          <h3>Classificação</h3>
        </div>

        <button className="link-button">Ver completa</button>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Time</th>
              <th>J</th>
              <th>V</th>
              <th>E</th>
              <th>D</th>
              <th>SG</th>
              <th>PTS</th>
            </tr>
          </thead>

          <tbody>
            {classificacao.map((item, index) => {
              const jogos = item.jogos ?? 0;
              const vitorias = item.vitorias ?? 0;
              const empates = item.empates ?? 0;
              const derrotas = item.derrotas ?? 0;
              const saldo = item.saldo ?? item.saldo_gols ?? 0;

              return (
                <tr key={item.id}>
                  <td>
                    <span className={`position position-${index + 1}`}>
                      {index + 1}
                    </span>
                  </td>

                  <td className="team-name">
                    <img
                      src={item.escudo}
                      alt={`Escudo do ${item.nome}`}
                      className="team-logo"
                    />
                    <span>{item.nome}</span>
                  </td>

                  <td>{jogos}</td>
                  <td>{vitorias}</td>
                  <td>{empates}</td>
                  <td>{derrotas}</td>
                  <td>{saldo > 0 ? `+${saldo}` : saldo}</td>
                  <td className="points">{item.pontos ?? 0}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </article>
  );
}

export default Tabela;