import { useEffect, useState } from "react";
import { supabase } from "../supabaseClient";
import Artilharia from "../components/Artilharia";

function Estatisticas() {
  const [artilheiros, setArtilheiros] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    async function buscarArtilharia() {
      const { data, error } = await supabase
        .from("jogadores")
        .select(`
          id,
          nome,
          gols,
          times (
            nome
          )
        `)
        .eq("ativo", true)
        .gt("gols", 0)
        .order("gols", { ascending: false })
        .order("nome", { ascending: true });

      if (error) {
        console.error("Erro ao buscar artilharia:", error);
        setArtilheiros([]);
      } else {
        const lista = (data || []).map((jogador) => ({
          ...jogador,
          time: jogador.times?.nome || "",
        }));

        setArtilheiros(lista);
      }

      setCarregando(false);
    }

    buscarArtilharia();
  }, []);

  return (
    <main className="page">
      <section className="page-header">
        <span className="panel-label">ESTATÍSTICAS</span>
        <h2>Estatísticas do Campeonato</h2>
        <p>Artilharia atualizada automaticamente.</p>
      </section>

      <div className="side-column">
        {carregando ? (
          <p style={{ color: "#fff", textAlign: "center" }}>
            Carregando artilharia...
          </p>
        ) : (
          <Artilharia artilheiros={artilheiros} />
        )}
      </div>
    </main>
  );
}

export default Estatisticas;