
import { useEffect, useState } from "react";
import { supabase } from "../supabaseClient";

function Jogadores() {
  const [jogadores, setJogadores] = useState([]);
  const [times, setTimes] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [salvandoId, setSalvandoId] = useState(null);

  useEffect(() => {
    async function carregarDados() {
      try {
        const [resJogadores, resTimes] = await Promise.all([
          supabase
            .from("jogadores")
            .select(`
              id,
              nome,
              capitao,
              jogos,
              gols,
              time_id,
              times (
                id,
                nome,
                escudo
              )
            `)
            .eq("ativo", true)
            .order("nome", { ascending: true }),

          supabase
            .from("times")
            .select("id, nome, escudo")
            .order("nome", { ascending: true }),
        ]);

        if (resJogadores.error) {
          console.error("Erro ao buscar jogadores:", resJogadores.error);
        }

        if (resTimes.error) {
          console.error("Erro ao buscar times:", resTimes.error);
        }

        setJogadores(resJogadores.data || []);
        setTimes(resTimes.data || []);
      } catch (erro) {
        console.error("Erro inesperado:", erro);
      } finally {
        setCarregando(false);
      }
    }

    carregarDados();
  }, []);

  async function alterarTime(jogadorId, novoTimeId) {
    setSalvandoId(jogadorId);

    const { error } = await supabase
      .from("jogadores")
      .update({ time_id: Number(novoTimeId) })
      .eq("id", jogadorId);

    if (error) {
      console.error("Erro ao trocar jogador de time:", error);
      alert("Não foi possível alterar o time.");
      setSalvandoId(null);
      return;
    }

    const novoTime = times.find((time) => time.id === Number(novoTimeId));

    setJogadores((listaAtual) =>
      listaAtual.map((jogador) =>
        jogador.id === jogadorId
          ? {
              ...jogador,
              time_id: Number(novoTimeId),
              times: novoTime,
            }
          : jogador
      )
    );

    setSalvandoId(null);
  }

  const jogadoresPorTime = times.map((time) => ({
    ...time,
    jogadores: jogadores.filter((jogador) => jogador.time_id === time.id),
  }));

  return (
    <main className="page">
      <section className="page-header">
        <span className="panel-label">ELENCOS</span>
        <h2>Jogadores</h2>
        <p>Altere o time dos jogadores diretamente pelo aplicativo.</p>
      </section>

      {carregando ? (
        <p style={{ color: "#fff", textAlign: "center" }}>
          Carregando jogadores...
        </p>
      ) : (
        <section className="players-grid">
          {jogadoresPorTime.map((time) => (
            <article className="team-card" key={time.id}>
              <div className="team-card-header">
                <img src={time.escudo} alt={`Escudo do ${time.nome}`} />

                <div>
                  <span className="panel-label">EQUIPE</span>
                  <h3>{time.nome}</h3>
                </div>
              </div>

              <div className="players-list">
                {time.jogadores.map((jogador, index) => (
                  <div className="player-row" key={jogador.id}>
                    <span>{index + 1}</span>

                    <strong>
                      {jogador.nome}
                      {jogador.capitao ? " (C)" : ""}
                    </strong>

                    <select
                      value={jogador.time_id}
                      disabled={salvandoId === jogador.id}
                      onChange={(evento) =>
                        alterarTime(jogador.id, evento.target.value)
                      }
                    >
                      {times.map((opcao) => (
                        <option key={opcao.id} value={opcao.id}>
                          {opcao.nome}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}

                {time.jogadores.length === 0 && (
                  <p style={{ color: "#9aa7bd" }}>
                    Nenhum jogador neste time.
                  </p>
                )}
              </div>
            </article>
          ))}
        </section>
      )}
    </main>
  );
}

export default Jogadores;