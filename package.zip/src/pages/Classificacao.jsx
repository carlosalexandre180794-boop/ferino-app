import { useEffect, useState } from "react";
import { supabase } from "../supabaseClient";
import Tabela from "../components/Tabela";

function Classificacao() {
  const [dadosClassificacao, setDadosClassificacao] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    async function buscarClassificacao() {
      try {
        // Busca os dados da tabela 'times' e ordena pelos pontos (decrescente)
        const { data, error } = await supabase
          .from("times")
          .select("*")
          .order("pontos", { ascending: false });

        if (error) {
          console.error("Erro ao buscar dados do Supabase:", error);
        } else {
          setDadosClassificacao(data || []);
        }
      } catch (err) {
        console.error("Erro inesperado:", err);
      } finally {
        setCarregando(false);
      }
    }

    buscarClassificacao();
  }, []);

  return (
    <main className="page">
      <section className="page-header">
        <span className="panel-label">CAMPEONATO MENSAL</span>
        <h2>Classificação completa</h2>
        <p>Tabela atualizada do Ferino Pé de Pano.</p>
      </section>

      {carregando ? (
        <p style={{ color: "#fff", textAlign: "center" }}>Carregando classificação...</p>
      ) : (
        <Tabela classificacao={dadosClassificacao} />
      )}
    </main>
  );
}

export default Classificacao;
