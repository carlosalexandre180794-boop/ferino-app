import { useEffect, useMemo, useState } from "react";
import { supabase } from "../supabaseClient";
import { escudoTime } from "../escudos";
function Home() {
  const [times, setTimes] = useState([]);
  const [artilheiros, setArtilheiros] = useState([]);
  const [goleiros, setGoleiros] = useState([]);
  const [partidas, setPartidas] = useState([]);
  const [totalJogadores, setTotalJogadores] = useState(0);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    async function carregarPainel() {
      const [resTimes, resArtilheiros, resGoleiros, resPartidas, resJogadores] =
        await Promise.all([
          supabase
            .from("times")
            .select(
              "id, nome, escudo, jogos, pontos, vitorias, empates, derrotas, gols_pro, gols_contra, saldo"
            )
            .order("pontos", { ascending: false })
            .order("vitorias", { ascending: false })
            .order("saldo", { ascending: false })
            .order("gols_pro", { ascending: false }),

          supabase
            .from("jogadores")
            .select("id, nome, gols, times(nome, escudo)")
            .eq("ativo", true)
            .gt("gols", 0)
            .order("gols", { ascending: false })
            .order("nome", { ascending: true })
            .limit(3),

          supabase
            .from("jogadores")
            .select(
              "id, nome, jogos_goleiro, gols_sofridos, times(nome, escudo)"
            )
            .eq("ativo", true)
            .eq("goleiro", true)
            .gt("jogos_goleiro", 0)
            .order("gols_sofridos", { ascending: true })
            .order("jogos_goleiro", { ascending: false }),

          supabase
            .from("partidas")
            .select("id, gols_a, gols_b, data_jogo, status")
            .eq("status", "finalizada"),

          supabase
            .from("jogadores")
            .select("id", { count: "exact", head: true })
            .eq("ativo", true),
        ]);

      if (resTimes.error) console.error("Erro ao carregar times:", resTimes.error);
      if (resArtilheiros.error)
        console.error("Erro ao carregar artilheiros:", resArtilheiros.error);
      if (resGoleiros.error)
        console.error("Erro ao carregar goleiros:", resGoleiros.error);
      if (resPartidas.error)
        console.error("Erro ao carregar partidas:", resPartidas.error);
      if (resJogadores.error)
        console.error("Erro ao contar jogadores:", resJogadores.error);

      setTimes(resTimes.data || []);
      setArtilheiros(resArtilheiros.data || []);
      setGoleiros(resGoleiros.data || []);
      setPartidas(resPartidas.data || []);
      setTotalJogadores(resJogadores.count || 0);
      setCarregando(false);
    }

    carregarPainel();
  }, []);

  const resumo = useMemo(() => {
    const jogosRealizados = partidas.length;
    const golsMarcados = partidas.reduce(
      (total, partida) => total + (partida.gols_a || 0) + (partida.gols_b || 0),
      0
    );

    return {
      jogosRealizados,
      golsMarcados,
      media:
        jogosRealizados > 0
          ? (golsMarcados / jogosRealizados).toFixed(1).replace(".", ",")
          : "0,0",
    };
  }, [partidas]);

  const lider = times[0];
  const artilheiro = artilheiros[0];

  const melhorGoleiro = useMemo(() => {
    if (goleiros.length === 0) return null;

    return [...goleiros]
      .map((goleiro) => ({
        ...goleiro,
        media:
          goleiro.jogos_goleiro > 0
            ? goleiro.gols_sofridos / goleiro.jogos_goleiro
            : 0,
      }))
      .sort(
        (a, b) =>
          a.media - b.media ||
          b.jogos_goleiro - a.jogos_goleiro ||
          a.nome.localeCompare(b.nome)
      )[0];
  }, [goleiros]);

  const flamengo = times.find((time) => time.nome === "Flamengo");
  const vasco = times.find((time) => time.nome === "Vasco");

  if (carregando) {
    return (
      <main>
        <p className="dashboard-loading">Carregando painel...</p>
      </main>
    );
  }

  return (
    <main className="home-dashboard">
      <section className="highlight-grid">
        <article className="highlight-card highlight-card-gold">
          <span className="highlight-title">LÍDER DO CAMPEONATO</span>

          <div className="highlight-content">
  <img
    className="highlight-shield"
    src={escudoTime(lider?.nome)}
    alt={lider?.nome}
  />

  <div>
    <h2>{lider?.nome || "Sem líder"}</h2>
    <p>
      <strong>{lider?.pontos || 0}</strong> pontos
    </p>
  </div>
</div>
        </article>

        <article className="highlight-card">
          <span className="highlight-title">ARTILHEIRO DO MÊS</span>

          <div className="highlight-content">
           <img
  className="highlight-shield"
  src={escudoTime(artilheiro?.times?.nome)}
  alt={artilheiro?.times?.nome}
/> 

            <div>
              <h2>{artilheiro?.nome || "Sem gols"}</h2>
              <p>
                <strong>{artilheiro?.gols || 0}</strong> gols
                {artilheiro?.times?.nome ? ` • ${artilheiro.times.nome}` : ""}
              </p>
            </div>
          </div>
        </article>
      </section>

      <section className="summary-grid">
        <article className="summary-card">
          <span>Jogos realizados</span>
          <strong>{resumo.jogosRealizados}</strong>
        </article>

        <article className="summary-card">
          <span>Gols marcados</span>
          <strong>{resumo.golsMarcados}</strong>
        </article>

        <article className="summary-card">
          <span>Média de gols</span>
          <strong>{resumo.media}</strong>
        </article>

        <article className="summary-card">
          <span>Jogadores</span>
          <strong>{totalJogadores}</strong>
        </article>
      </section>

      <section className="home-content-grid">
        <article className="home-panel standings-home-panel">
          <div className="home-panel-header">
            <div>
              <span>CLASSIFICAÇÃO</span>
              <h3>Tabela mensal</h3>
            </div>
          </div>

          <div className="home-table-wrapper">
            <table className="home-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Time</th>
                  <th>J</th>
                  <th>V</th>
                  <th>E</th>
                  <th>D</th>
                  <th>GP</th>
                  <th>GC</th>
                  <th>SG</th>
                  <th>PTS</th>
                </tr>
              </thead>

              <tbody>
                {times.map((time, index) => (
                  <tr key={time.id}>
                    <td>
                      <span className={`home-position home-position-${index + 1}`}>
                        {index + 1}
                      </span>
                    </td>

                   <td className="home-team">
  <div className="home-team-info">
    <img
  src="/escudos/flamengo.png"
  alt="Flamengo"
  className="escudo"
/>

    <>
  <strong>{time.nome}</strong>
  <br />
  <small>{escudoTime(time.nome)}</small>
</>
  </div>
</td>

                    <td>{time.jogos || 0}</td>
                    <td>{time.vitorias || 0}</td>
                    <td>{time.empates || 0}</td>
                    <td>{time.derrotas || 0}</td>
                    <td>{time.gols_pro || 0}</td>
                    <td>{time.gols_contra || 0}</td>
                    <td className={(time.saldo || 0) >= 0 ? "positive" : "negative"}>
                      {(time.saldo || 0) > 0 ? `+${time.saldo}` : time.saldo || 0}
                    </td>
                    <td className="home-points">{time.pontos || 0}</td>
                      </tr>
  ))}
</tbody>
            </table>
          </div>
        </article>

        <div className="home-side-column">
          <article className="home-panel next-match-panel">
            <div className="home-panel-header">
              <div>
                <span>PRÓXIMA RODADA</span>
                <h3>Próximo jogo</h3>
              </div>
            </div>

            <div className="next-match">
              <div className="next-team">
                <img
  className="escudo-jogo"
  src={escudoTime("Flamengo")}
  alt="Flamengo"
/>
                
                <strong>Flamengo</strong>
              </div>

              <div className="next-match-center">
                <strong>X</strong>
                <span>Sábado • 16:00</span>
              </div>

              <div className="next-team">
                <img
  className="escudo-jogo"
  src={escudoTime("Vasco")}
  alt="Vasco"
/>
                <strong>Vasco</strong>
              </div>
            </div>
          </article>

          <div className="bottom-highlight-grid">
            <article className="home-panel compact-panel">
              <div className="home-panel-header">
                <div>
                  <span>ARTILHARIA</span>
                  <h3>Top 3</h3>
                </div>
              </div>

              <div className="ranking-list">
                {artilheiros.map((jogador, index) => (
                  <div className="ranking-item" key={jogador.id}>
                    <span className={`ranking-number ranking-number-${index + 1}`}>
                      {index + 1}
                    </span>

                    <div className="ranking-player">
  <img
    className="mini-shield"
    src={escudoTime(jogador.times?.nome)}
    alt={jogador.times?.nome}
  />

  <div>
    <strong>{jogador.nome}</strong>
    <small>{jogador.times?.nome}</small>
  </div>
</div>

                    <b>{jogador.gols}</b>
                  </div>
                ))}

                {artilheiros.length === 0 && (
                  <p className="empty-message">Nenhum gol registrado.</p>
                )}
              </div>
            </article>

            <article className="home-panel compact-panel">
              <div className="home-panel-header">
                <div>
                  <span>GOLEIRO DO MÊS</span>
                  <h3>{melhorGoleiro?.nome || "Sem dados"}</h3>
                </div>
              </div>

              {melhorGoleiro ? (
                <div className="goalkeeper-summary">
                  <img
  className="highlight-shield"
  src={escudoTime(melhorGoleiro.times?.nome)}
  alt={melhorGoleiro.times?.nome}
/>

                  <p>{melhorGoleiro.times?.nome || ""}</p>

                  <div className="goalkeeper-numbers">
                    <span>
                      <strong>{melhorGoleiro.jogos_goleiro}</strong>
                      jogos
                    </span>
                    <span>
                      <strong>{melhorGoleiro.gols_sofridos}</strong>
                      gols sofridos
                    </span>
                    <span>
                      <strong>{melhorGoleiro.media.toFixed(2).replace(".", ",")}</strong>
                      média
                    </span>
                  </div>
                </div>
              ) : (
                <p className="empty-message">Nenhum goleiro registrado.</p>
              )}
            </article>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Home;
